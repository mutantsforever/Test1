----------------bat2exeIEXP.BAT---------

bat2exeIEXP.bat batch file converts the [.bat] file to [.exe].
It uses inbuilt IExpress tool of windows for conversion.


