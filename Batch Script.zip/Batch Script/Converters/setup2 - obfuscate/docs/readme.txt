----------------Obfuscate.BAT---------

Obfuscate.bat batch file converts the [.bat] file to [obf.bat].
The task of this bat file is to create new obf.bat file from given bat file.
It obfuscates the code and makes it unreadable.


