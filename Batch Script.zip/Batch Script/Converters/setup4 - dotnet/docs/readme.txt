----------------Converter.BAT---------

Converter.bat batch file converts the [.bat] file to [.exe].
It uses jsc.exe (dontnet js compiler) to creqate exe files.


