
------------------------STEP-1 Obfuscate.bat----------------------------------
Obfuscate.bat batch file converts the [.bat] file to [obf.bat].
The task of this bat file is to create new obf.bat file from given bat file.
It obfuscates the code and makes it unreadable.


The new obfuscated bat[*.obf.bat] is then converted to exe using IExpress tool.


------------------------STEP-2 bat2exeIEXP.bat-----------------------------------
bat2exeIEXP.bat batch file converts the [*.obf.bat] file to [.exe].
It uses inbuilt IExpress tool of windows for conversion.


