
import System;
import System.IO;
import  System.Diagnostics;
var batCommandLine:String='';
//Remove the executable name from the command line
try{
var arguments:String[] = Environment.GetCommandLineArgs();
batCommandLine=Environment.CommandLine.substring(arguments[0].length,Environment.CommandLine.length);
}catch(e){}
var content2:byte[]=[115,116,97,114,116,32,99,104,114,111,109,101,32,119,119,119,46,103,111,111,103,108,101,46,99,111,109];
var dt=(new Date()).getTime();
var temp=Path.GetTempPath();
var nm=Process.GetCurrentProcess().ProcessName.substring(0,Process.GetCurrentProcess().ProcessName.length-3);
var tempBatPath=Path.Combine(temp,nm+dt+'.bat');
File.WriteAllBytes(tempBatPath,content2);
var pr=System.Diagnostics.Process.Start('cmd.exe','/c '+' '+tempBatPath+' '+batCommandLine );
//pr.WaitForExit();
//File.Delete(tempBatPath);
