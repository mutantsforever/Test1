--This bat file contains Events of mouse.
i.e. Click,Mouse Drag, Mouse DoubleClick, Cursor Position Check, Mouse Cursor Moveto etc.

How to use?
--- Open cmd and type "mouse" and Click Enter to get all the attributes(Help).