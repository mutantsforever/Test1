scripts to check new file and check changes in the file.
convert all file extensions from .txt to .bat