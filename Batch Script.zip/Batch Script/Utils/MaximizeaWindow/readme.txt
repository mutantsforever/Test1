This uses SendKeys function to Maximize a screen.

Replace the default .txt path to your own text file's path and run.