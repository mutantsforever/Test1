This sends the file present on the local machine to the Mainframe.

Replace the default paths with your required file path and PDS/PS paths and run the .bat file.