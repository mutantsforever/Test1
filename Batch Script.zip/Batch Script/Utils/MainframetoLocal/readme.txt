This sends the file present on the Mainframe to the local machine.

Replace the default paths with your required file path and PDS/PS paths and run the .bat file.