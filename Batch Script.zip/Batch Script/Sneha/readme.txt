-- Move this .bat file into the folder for which the file names you want to display.

-- Run this and a text file will be created with the names of the files present.