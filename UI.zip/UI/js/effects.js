	$(document).ready(function()
			{
				$(".divTable").hide();
			});
			function showTable()
			{
				$(".divTable").show(500);
			}